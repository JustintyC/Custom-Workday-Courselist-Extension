export const workdayDomComponents = {
    "courseListContainer": 'div.WC-N.WGYN',
    "courseListContainerParent": "div.WFYN.WKYN.WF5",
    "courseListItem": "li.WLUF.WD0N.WF5.WCWF",
    "expandButton": 'div[role="button"][data-automation-id="expandAll"]',
    "urlDiv": "div.WLNO.WFMO.WPMO", // should be the course name div's parent
    "barAboveList": "span.WNYN.WA-N",
}